export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  originalPrice?: number;
  coverImage: string;
  rating: number;
  reviewCount: number;
  isbn: string;
  publisher: string;
  publishDate: string;
  description: string;
  category: string;
  language: string;
  format: 'Hardcover' | 'Paperback' | 'eBook';
  stockStatus: 'In Stock' | 'Out of Stock' | 'Pre-order';
}