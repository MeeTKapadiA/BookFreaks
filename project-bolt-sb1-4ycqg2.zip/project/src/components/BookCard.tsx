import React from 'react';
import { Star } from 'lucide-react';
import { Book } from '../types/book';
import { useCartStore } from '../store/useCartStore';

interface BookCardProps {
  book: Book;
}

export function BookCard({ book }: BookCardProps) {
  const addItem = useCartStore((state) => state.addItem);

  const discount = book.originalPrice
    ? Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100)
    : 0;

  return (
    <div className="group relative bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]">
      <div className="aspect-h-1 aspect-w-1 w-full overflow-hidden bg-gray-200">
        <img
          src={book.coverImage}
          alt={book.title}
          className="h-full w-full object-cover object-center"
        />
      </div>
      <div className="p-4">
        <h3 className="text-sm font-medium text-gray-900 truncate">{book.title}</h3>
        <p className="mt-1 text-sm text-gray-500">{book.author}</p>
        <div className="mt-2 flex items-center">
          <Star className="h-4 w-4 text-yellow-400 fill-current" />
          <span className="ml-1 text-sm text-gray-600">
            {book.rating} ({book.reviewCount})
          </span>
        </div>
        <div className="mt-2">
          <span className="text-lg font-bold text-gray-900">${book.price}</span>
          {book.originalPrice && (
            <>
              <span className="ml-2 text-sm text-gray-500 line-through">
                ${book.originalPrice}
              </span>
              <span className="ml-2 text-sm font-medium text-green-600">
                {discount}% off
              </span>
            </>
          )}
        </div>
        <button
          onClick={() => addItem(book)}
          className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}