import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ShoppingCart } from 'lucide-react';
import { useCartStore } from '../store/useCartStore';
import { featuredBooks } from '../data/books';

export function BookDetailsPage() {
  const { id } = useParams();
  const addItem = useCartStore((state) => state.addItem);
  const book = featuredBooks.find((b) => b.id === id);

  if (!book) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Book not found</h2>
          <Link to="/" className="text-blue-600 hover:text-blue-700">
            Return to homepage
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <img
            src={book.coverImage}
            alt={book.title}
            className="w-full rounded-lg shadow-lg"
          />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{book.title}</h1>
          <p className="text-xl text-gray-600 mb-4">by {book.author}</p>
          
          <div className="flex items-center mb-6">
            <Star className="h-5 w-5 text-yellow-400 fill-current" />
            <span className="ml-2 text-lg text-gray-700">
              {book.rating} ({book.reviewCount} reviews)
            </span>
          </div>

          <div className="mb-6">
            <span className="text-3xl font-bold text-gray-900">${book.price}</span>
            {book.originalPrice && (
              <span className="ml-3 text-xl text-gray-500 line-through">
                ${book.originalPrice}
              </span>
            )}
          </div>

          <div className="prose prose-lg mb-8">
            <p>{book.description}</p>
          </div>

          <div className="space-y-4 mb-8">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">ISBN</h3>
                <p className="text-base text-gray-900">{book.isbn}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Publisher</h3>
                <p className="text-base text-gray-900">{book.publisher}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Format</h3>
                <p className="text-base text-gray-900">{book.format}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Language</h3>
                <p className="text-base text-gray-900">{book.language}</p>
              </div>
            </div>
          </div>

          <button
            onClick={() => addItem(book)}
            className="w-full flex items-center justify-center bg-blue-600 text-white py-3 px-8 rounded-md hover:bg-blue-700 transition-colors"
          >
            <ShoppingCart className="h-5 w-5 mr-2" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}