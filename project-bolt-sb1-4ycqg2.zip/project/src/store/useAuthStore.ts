import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AuthState, User } from '../types/user';

interface AuthStore extends AuthState {
  login: (user: User) => void;
  logout: () => void;
  signup: (email: string, password: string, name: string) => Promise<User>;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (user) => set({ user, isAuthenticated: true }),
      logout: () => set({ user: null, isAuthenticated: false }),
      signup: async (email: string, password: string, name: string) => {
        // In a real app, this would make an API call to create the user
        const newUser = {
          id: Math.random().toString(36).substr(2, 9),
          email,
          name,
        };
        set({ user: newUser, isAuthenticated: true });
        return newUser;
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);